<?php get_template_part( 'partials/header' , 'logo' ); ?>
			
<div class="navbar-collapse tpath-mainnavbar-collapse collapse tpath-header-main-bar">
	<ul class="nav navbar-nav tpath-main-bar">
		<li class="header-top-left"><?php justice_header_content_area( 'main-navigation' ); ?></li>
	</ul>
</div>